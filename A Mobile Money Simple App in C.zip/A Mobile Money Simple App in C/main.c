#include <stdio.h>
#include <stdlib.h>
int menu(int solde)
{
 int choix=0;
  while(choix<1 || choix>4)
   {
       if(solde==0)
     {
      printf("Bienvenue sur le Service Mobile Money du reseau Asking-Telecom. Votre solde  est de %d Francs.Nous vous conseillons de recharger votre compte dans un premier temps.\nVeuilllez choisir une option:\n ---Menu--- \n 1-Envoyer de l'argent \n 2-Recharger votre credit \n 3-Recevoir de l'argent \n 4-Afficher le solde et le credit\n\n\n",solde);
    scanf("%d",&choix);
     }
       else
        {
            printf("Bienvenue sur le Service Mobile Money du reseau Asking-Telecom. Votre solde  est de %d Francs.\nVeuilllez choisir une option:\n ---Menu--- \n 1-Envoyer de l'argent \n 2-Recharger votre credit \n 3-Recevoir de l'argent \n 4-Afficher le solde et le credit\n\n\n",solde);
    scanf("%d",&choix);
        }
   }
  return choix;
}

int main()

{
    int montant, solde=0, credit=0, numero, exit, code;
    do
{
switch(menu(solde))
{
    case 3:
    printf("Entrez le montant que vous voulez recevoir:\n");
    scanf("%d",&montant);
    if(montant>0)
    {
    solde=solde+montant;
    printf("Rechargement effectue. Votre nouveau solde est de %d FCFA. \n",solde);
    }
    else
        {
            printf("Le montant entre ne figure pas parmis les options permises.Veuillez reverifiez votre choix.\n");
        }
    break;

    case 2:
        printf("Entrez votre mot de passe pour continuer:\n");
        scanf("%d",&code);
     if(code==5678)
     {
    printf("Entrez le montant du credit souhaite: \n");
    scanf ("%d", &credit);
    if (solde<credit)
    {
        printf("Votre solde est insuffisant pour effectuer cette requette. \n");
    }
    else
    {
        printf("Le rechargement a ete effectue. Vodre credit est de %d et votre solde est de %d.\n",credit,solde-credit);
        solde=solde-credit;
    }
     }
     if(code!=5678)
     {
         printf("Le code pin est inexact.\n");
     }
    break;
    case 4:
        printf("Entrez votre mot de passe: ");
        scanf("%d",&code);
        if(code==5678)
        {
        printf("Votre solde est de %d francs CFA et votre credit est de %d.\n",solde,credit);
        }
        else
            {
                printf("Reverifiez votre mot de passe. \n");
            }
    break;
    case 1:
        printf("Veuillez entrez votre mot de passe pour confirmez votre choix: \n");
        scanf("%d",&code);
        if (code==5678)
      {
          printf("Entrez le montant que vous souhaitez envoyez:\n");
        scanf("%d",&montant);
        if(montant>solde)
        {
          printf("Votre solde est insuffisant pour effectuer cette requette.");
        }
        else
        {
            printf("Veuillez entrez le numero a 8 chiffres du receveur:\n");
            scanf ("%d",&numero);
            if(numero>9999999 && numero<99999999)
          {
              solde=solde-montant;
            printf("Le transfert a ete effectue au %d et votre nouveau solde est de %d Francs CFA \n", numero, solde);
          }
            else
            {
             printf("Le numero entre est incorrecte.Le transfert n'a donc pas ete effectue. \n");
            }
        }
      }
        else
        {
            printf("Le code entre est inexact!\n");
        }
        break;
}
        printf("Si vous voulez sortir appuyez sur 0 sinon appuyer n'importe quel autre nombre: \n");
        scanf("%d",&exit);
}while(exit!=0);

 return 0;
}


