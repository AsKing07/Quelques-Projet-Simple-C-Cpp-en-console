#ifndef CYLINDRE_H_INCLUDED
#define CYLINDRE_H_INCLUDED


// Cylindre.h

        class Cylindre
        {

        public:

        // Constructeurs

        Cylindre(double r=1, double h=1);

        Cylindre(Cylindre const& original);



        // Methodes

        double perimetre() const;

        double aire_base() const;

        double aire_laterale() const;

        double aire_totale() const;

        double volume() const;



        bool agrandir(double facteur);

        bool allonger(double facteur);

        bool dilater(double facteur);



        // Accesseurs

        double get_rayon() const;

        double get_hauteur() const;



        // Mutateurs

        bool set_rayon(double r);

        bool set_hauteur(double h);



        ~Cylindre();


        private:

        double rayon;

        double hauteur;

       };






#endif // CYLINDRE_H_INCLUDED
