// Cylindre.cpp

#define _USE_MATH_DEFINES

#include <cmath>
#include "Cylindre.h"

        using namespace std;

        Cylindre::Cylindre(double r, double h)
        {

        if(r<0)


        rayon=(-r);

        else if(r==0)


        rayon=1;

        else


        rayon=r;



        if(h<0)


        hauteur=(-h);

        else if(h==0)


        hauteur=1;

        else


        hauteur=h;
        }

        Cylindre::Cylindre(Cylindre const& original):

        rayon(original.rayon),

        hauteur(original.hauteur)
        {
        }

        double Cylindre::perimetre() const
        {

        return 2*M_PI*rayon;
        }

        double Cylindre::aire_base() const
        {

        return M_PI*rayon*rayon;
        }

        double Cylindre::aire_laterale() const
        {

        return perimetre()*hauteur;
        }

        double Cylindre::aire_totale() const
        {

        return aire_laterale() + (2 * aire_base());
        }

        double Cylindre::volume() const
        {

        return aire_base() * hauteur;
        }

        bool Cylindre::agrandir(double facteur)
        {

        rayon*=facteur;

        hauteur*=facteur;
        }

        bool Cylindre::allonger(double facteur)
        {

        hauteur*=facteur;

        return true;
        }

        bool Cylindre::dilater(double facteur)
        {

        rayon*=facteur;

        return true;
        }

        double Cylindre::get_rayon() const
        {

        return rayon;
        }

        double Cylindre::get_hauteur() const
        {

        return hauteur;
        }

        bool Cylindre::set_rayon(double r)
        {

        if(r<0)


        rayon=(-r);

        else if(r==0)


        rayon=1;

        else


        rayon=r;

        return true;
        }

        bool Cylindre::set_hauteur(double h)
        {

        if(h<0)


        hauteur=(-h);

        else if(h==0)


        hauteur=1;

        else


        hauteur=h;

        return true;
        }

        Cylindre::~Cylindre()
        {
        }
