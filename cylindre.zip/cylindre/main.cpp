#include <iostream>
#include "Cylindre.h"


using namespace std;

int main()
{


    double radius, height;



        cout<<"Faisons un cylindre ensemble."<<endl;

        cout<<"Saisissez un rayon: ";

        cin>>radius;

        cout<<"Saisissez une hauteur: ";

        cin>>height;



        Cylindre un_cylindre(radius,height);


        cout<<"Nous avons fait un cylindre de rayon "<<un_cylindre.get_rayon();

        cout<<" et de hauteur "<<un_cylindre.get_hauteur()<<endl;

        cout<<"Le volume du cylindre est "<<un_cylindre.volume()<<endl;



        cout<<endl<<"Attention! Notre cylindre s'allonge!!"<<endl;

        un_cylindre.allonger(2);

        cout<<"Notre cylindre est maintenant plus long. Sa nouvelle hauteur est"<<un_cylindre.get_hauteur()<<endl;

        cout<<"Le volume du cylindre est maintenant "<<un_cylindre.volume()<<endl;



    return 0;
}
