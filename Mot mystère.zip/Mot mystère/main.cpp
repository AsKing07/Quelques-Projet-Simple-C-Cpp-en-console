#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>
#include <stdio.h>
#include <stdlib.h>
using namespace std;


void correction(string mot,string motdevin,int& score1,int& score2)
{
    if(motdevin==mot)
    {
        cout<<"Felicitation vous avez trouve� le mot."<<endl;
        score2+=1;
        score1-=1;
    }
    else
    {
        cout<<"Dommage vous y �tiez presque.Veuillez r�essayer."<<endl;
        score1+=1;
        score2-=1;
    }
}


string melangerLettres(string mot)
{
   string melange;
   int position(0);
   //Tant qu'on n'a pas extrait toutes les lettres du mot
   while (mot.size() != 0)
   {
      //On choisit un num�ro de lettre au hasard dans le mot
      position=rand()%mot.size();
      //On ajoute la lettre dans le mot m�lang�
       melange +=mot[position];
      //On retire cette lettre du mot myst�re
      //Pour ne pas la prendre une deuxi�me fois
        mot.erase(position,1);
    }
   //On renvoie le mot m�lang�
   return melange;
}



int menu(int choix)
{

    while (choix<1 || choix>3)
    {
       cout << "Bienvenue dans le jeu du MOT MYSTERE.Le principe est simple:" << endl<<"Le joueur 1 entre un mot et le joueur 2 le devine.Vos scores sont initialises a 10."<<endl;
       cout<<"MENU"<<endl<<"1-Jouer"<<endl<<"2-Voir les scores de la partie"<<endl<<"3-Quitter"<<endl;
       cin>>choix;
    }

    return choix;

}

int main()

{
     srand(time(0));
     int score1(10), score2(10);
        int quit;


    do
    {

        int choix(0);
         string joueur1, joueur2, mot, motdevin, motmelange;
        switch(menu(choix))
        {



            case 1:
            cout<<"Entrez le nom du joueur 1 suivi de celui du joueur 2:"<<endl;
            cin>>joueur1>>joueur2;

            cout<<joueur1<<" veuillez entrez le mot � deviner:"<<endl;
            cin>>mot;
            motmelange=melangerLettres(mot);
             system("cls");

            cout<<motmelange<<endl;

            cout<<joueur2<<" veuillez deviner le mot myst�re: "<<endl;
            cin>>motdevin;


            correction(mot,motdevin,score1,score2);
            break;

            case 2:

                cout<<joueur1<<":"<<score1<<endl;
                cout<<joueur2<<":"<<score2<<endl;
                break;

            case 3:
                return 0;
                break;

            default :
                cout<<"Veuillez red�marrer le programme et v�rifier vos choix"<<endl;
                break;


            }

        cout<<"Pour quitter appuyez sur 1 sinon appuyez sur n'importe quel autre touche:"<<endl;
        cin>>quit;

    }while(quit!=1);




    return 0;
}
