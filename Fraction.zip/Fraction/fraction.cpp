#include "fraction.h";
#include <iostream>

using namespace std;


    fraction::fraction(int nume, int deno)
    {


            if (deno<0)
            {
                deno=deno*(-1);
            }

            if (nume<0)
            {
                nume=nume*(-1);
            }

            if(nume<deno)
            {
                fraction::permut(nume,deno);
            }

            numerateur=nume;
            denominateur=deno;
    }


   void fraction::permut(int& a, int& b)
   {
        int tmp;
        tmp=a;
        a=b;
        b=tmp;
   }

    int fraction::get_num() const
    {
        return numerateur;
    }
    int fraction::get_den() const
    {
        return denominateur;
    }

  void fraction::transformation()
  {
      int num,den,a,b,c;

     num=get_num();
     den=get_den();

     if(den==0)
     {
         cout<<"Impossible, denominateur egal � 0";
     }
     else
     {
         b=num%den;
         a=num/den;
         c=den;

         cout<<"La fraction transformee est "<<a<<" + "<<b<<"/"<<c<<" ."<<endl;
     }


  }




