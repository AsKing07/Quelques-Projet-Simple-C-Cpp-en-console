#include <iostream>
#include "fraction.h"

using namespace std;


int main()
{
    int num,den;
    cout << "Entrez le num�rateur de telle sorte qu'il soit plus grand que le denominateur: ";
    cin>>num;
    cout<<endl;

    cout << "Entrez le denominateur de telle sorte qu'il soit plus petit que le denominateur et different de 0: ";
    cin>>den;

    cout<< "Notez que si le numerateur est plus petit que le denominateur, ils seront permutes."<<endl<<endl;

    fraction fract(num,den);

    cout<<"Le numerateur final est: "<<fract.get_num()<<" et le denominateur final est: "<<fract.get_den()<<" ."<<endl;




    fract.transformation();





    return 0;
}
