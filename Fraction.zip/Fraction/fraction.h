#ifndef FRACTION_H_INCLUDED
#define FRACTION_H_INCLUDED

class fraction

{
public:

    fraction(int numerateur, int denominateur);

    void transformation();

    void permut(int& a, int& b);

    int get_num() const;
    int get_den() const;

private:
    int numerateur;
    int denominateur;

};


#endif // FRACTION_H_INCLUDED
