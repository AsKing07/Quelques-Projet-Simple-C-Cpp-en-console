#include "animal.h"
#include <iostream>

using namespace std;


       animal::animal(string nom, int peau, int membre, int respiration, int naissance)
       {
           m_nom=nom;
           m_peau=peau;
           m_membre=membre;
           m_respiration=respiration;
           m_naissance=naissance;
       }

       void animal::nature()
       {
           if(m_peau==2 && m_membre==2 && m_respiration==1  && m_naissance==1 )
           {
               cout<<m_nom<< " est un mammif�re";
           }

           else if (m_peau==3 && m_membre==3 && m_respiration==2  && m_naissance==2 )
           {
                cout<<m_nom<< " est un poisson";
           }

           else if (m_peau==3 && m_membre==4 && m_respiration==1  && m_naissance==2 )
           {
                cout<<m_nom<< " est un reptile";
           }

           else if (m_peau==4 && (m_membre==4 || m_membre==2) && m_respiration==1  && m_naissance==2 )
           {
                cout<<m_nom<< " est un oiseau";
           }

            else if (m_peau==1 && m_membre==4  && m_respiration==1  && m_naissance==2 )
           {
                cout<<m_nom<< " est un amphibien";
           }

           else
           {
               cout<<"Nous n'avons pas pu d�terminer la cat�gorie de votre animal.";
           }
       }



