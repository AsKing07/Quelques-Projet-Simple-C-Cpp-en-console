#ifndef ANIMAL_H_INCLUDED
#define ANIMAL_H_INCLUDED
#define DEF_ANIMAL
#include <string>


class animal
{
public:
    //Constructeur

    animal(std::string nom, int peau, int membre, int respiration, int naissance);
     void nature();


private:
    std::string m_nom;
    int m_peau;
    int m_membre;
    int m_naissance;
    int m_respiration;


};



#endif // ANIMAL_H_INCLUDED
