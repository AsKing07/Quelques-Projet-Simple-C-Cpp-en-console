#include <iostream>
#include <string>
#include "animal.h"

using namespace std;

int main()
{
    string nom;
    int naissance=0, respiration(0), peau(0), membre(0);

    cout << "Entrez le nom de votre animal:" << endl;
    cin>>nom;

    while(naissance<1 || naissance>2)
    {
        cout << "Comment naissent les petits de votre animal?"<<endl<<"1-Par accouchement"<<endl<<"2-En pondant des oeufs"<<endl;
        cin>>naissance;
    }

    while(respiration<1 || respiration>2)
    {
        cout << "Comment respire-t-il?"<<endl<<"1-L'air terrestre"<<endl<<"2-Sous l'eau"<<endl;
        cin>>respiration;
    }

     while(peau<1 || peau>4)
    {
        cout << "De quoi sa peau est recouverte?"<<endl<<"1-Rien, il a une peau nue"<<endl<<"2-De Poil"<<endl<<"3-Ecaille"<<endl<<"4-De Plumes"<<endl;
        cin>>peau;
    }

     while(membre<1 || membre>4)
    {
        cout << "Combien de membres a-t-il?"<<endl<<"1- 2"<<endl<<"2- 4"<<endl<<"3- Il a plutot des nageoires"<<endl<<"4- Aucun"<<endl;
        cin>>membre;
    }

    animal MonAnimal(nom, peau, membre, respiration, naissance);

    MonAnimal.nature();





    return 0;
}
