#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include "fonctionsEcriture.h"
#include "fonctionsLecture.h"
#include <algorithm>


void menu(string cheminFichier);



#endif // MENU_H_INCLUDED
