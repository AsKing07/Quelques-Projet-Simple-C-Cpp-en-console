#ifndef FONCTIONSECRITURE_H_INCLUDED
#define FONCTIONSECRITURE_H_INCLUDED
#include <iostream>
#include <sstream>
#include <fstream>
#include <string.h>
#include <algorithm>


using namespace std;

void ajout_cmp_pfl(string cheminFichier);

void retirer_cmp_pfl(string cheminFichier);

void ajout_cmp_pro(string cheminFichier);

void retirer_cmp_pro(string cheminFichier);




#endif // FONCTIONSECRITURE_H_INCLUDED
