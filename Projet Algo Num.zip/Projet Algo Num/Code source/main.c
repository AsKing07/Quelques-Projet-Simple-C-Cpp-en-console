#include <stdio.h>

// Fonction pour afficher une matrice avec une pr�cision de 3 chiffres apr�s la virgule
void afficherMatrice(double matrice[][4], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%.3f\t", matrice[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

// Fonction pour effectuer la factorisation LU
void factorisationLU(double A[][4], double L[][4], double U[][4], int n) {
    // �tape de factorisation LU
    for (int i = 0; i < n; i++) {
        // Calcul des �l�ments de la matrice U
        for (int k = i; k < n; k++) {
            double somme = 0.0;
            for (int j = 0; j < i; j++) {
                somme += L[i][j] * U[j][k];
            }
            U[i][k] = A[i][k] - somme;
        }

        // Calcul des �l�ments de la matrice L
        for (int k = i; k < n; k++) {
            if (i == k) {
                L[i][i] = 1.0;
            } else {
                double somme = 0.0;
                for (int j = 0; j < i; j++) {
                    somme += L[k][j] * U[j][i];
                }
                L[k][i] = (A[k][i] - somme) / U[i][i];
            }
        }
    }
}

// Fonction pour r�soudre le syst�me d'�quations lin�aires
void resoudreSysteme(double L[][4], double U[][4], double b[], double x[], int n) {
    double y[4] = {0.0};

    // R�solution de Ly = b
    for (int i = 0; i < n; i++) {
        double somme = 0.0;
        for (int j = 0; j < i; j++) {
            somme += L[i][j] * y[j];
        }
        y[i] = b[i] - somme;
    }

    // R�solution de Ux = y
    for (int i = n - 1; i >= 0; i--) {
        double somme = 0.0;
        for (int j = i + 1; j < n; j++) {
            somme += U[i][j] * x[j];
        }
        x[i] = (y[i] - somme) / U[i][i];
    }
}

int main() {
    // Matrice A
    double A[4][4] = {
        {-9, 5, -5, 12},
        {3, -7, -2, 2},
        {6, -4, 0, -5},
        {-3, 5, 1, 0}
    };

    // Vecteur b
    double b[4] = {11, -9, 7, 5};

    // Affichage de la matrice A
    printf("Matrice A :\n");
    afficherMatrice(A, 4);



    // Affichage du vecteur b
    printf("Vecteur b :\n");
    for (int i = 0; i < 4; i++) {
        printf("%.3f\n", b[i]);
    }
    printf("\n");

    // Factorisation LU
    double L[4][4], U[4][4];
    factorisationLU(A, L, U, 4);

    // Affichage de la matrice L
    printf("Matrice L :\n");
    afficherMatrice(L, 4);

    // Affichage de la matrice U
    printf("Matrice U :\n");
    afficherMatrice(U, 4);

    // R�solution du syst�me d'�quations
    double x[4];
    resoudreSysteme(L, U, b, x, 4);

    // Affichage de la solution
    printf("Solution [X] :\n");
    for (int i = 0; i < 4; i++) {
        printf("%.3f\n", x[i]);
    }

     getchar();
return 0;
}
