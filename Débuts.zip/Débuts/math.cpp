#include "math.h"
#include <iostream>

void ajouteDeux(double& a)
{
    int premierevaleur(a);
    a+=2;
    std::cout<<premierevaleur<<"+2="<<a;
}
