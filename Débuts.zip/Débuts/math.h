#ifndef MATH_H_INCLUDED
#define MATH_H_INCLUDED

void ajouteDeux(double& a);


#endif // MATH_H_INCLUDED
