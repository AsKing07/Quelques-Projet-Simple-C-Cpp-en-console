#include <iostream>  //Inclut la biblioth�que iostream (affichage de texte)
#include <string> //Inclut l'utilisation des chaines de caract�re
#include "math.h"
#include <vector>  //Necessaire pour utiliser les tableaux dynamiques(vecteur)
#include <array>  //tableau
#include <fstream>// Pour lire et ecrire dans les fichiers

using namespace std; //Indique quel espace de noms on va utiliser

/*
Fonction principale "main"
Tous les programmes commencent par la fonction main
*/

double moyenne(double tableau[], int nbr)
{
    double moy(0);
    int i;
    for(i=0;i<nbr;i++)
    {
        moy+=tableau[i];
    }
    moy/=nbr;
    return moy;
}

int secondes(int j, int h, int m, int s=0)
{
    int total;
    total=(j*86400)+(h*3600)+(60*m)+s;
    return total;
}


int main()
{
    int nbre(49);
    cout << "Mon papa a : "<<nbre <<"moutons" << endl;  //cout est un flux et nous permet de faire ce que printf faisait en C

    /**********COMPARAISON ET DIVISION*************/
    int a,b;
    cout <<"Entrez deux nombres: "<< endl;
    cin>>a>>b;
    if(a<b)
    {
        cout<<"Le plus grand est: "<<b<<"." << endl;
    }
    else if(a>b)
    {
        cout<<"Le plus grand est: "<<a<<"."<<endl;
    }
    else
    {
        cout<<"Les deux nombres sont egaux."<<endl;
    }

    if(b!=0 && a%b==0)
    {
        cout<<"Le nombre "<<a<<" est divisible par "<< b<<"."<<endl;
    }
    else if (b==0)
    {
        cout<<"Impossible de diviser par 0"<<endl;
    }
    else
    {
        cout<<"Le nombre "<<a<<" n'est pas divisible par "<<b<<"."<<endl;
    }

    /*************************NOMBRE DE SECONDES*******************/

    int j,h,m,s;

    cout<<"Entrez le nombre de jours:";
    cin>>j;

    cout<<"Entrez le nombre d'heures:";
    cin>>h;

    cout<<"Entrez le nombre de minutes:";
    cin>>m;

    cout<<"Entrez le nombre de secondes:";
    cin>>s;

    cout<<"Au total il y a: "<<secondes(j,h,m,s)<<"secondes.";

    /*************************REFERENCES*************************/
     int ageUtilisateur(18);//Une variable  pour contenir l'�ge de l'utilisateur
     int& maReference(ageUtilisateur);//Et une r�f�rence sur la variable 'ageUtilisateur'
    //On peut utiliser � partir  d'ici
    // 'ageUtilisateur' ou 'maReference'indistinctement
    //Puisque ce sont deux �tiquettes de la m�me  case en m�moire
    cout << "Vous avez " << ageUtilisateur<<"ans.(via  variable)"<<endl;//On affiche,de la mani�re habituelle
    cout << "Vous avez "<<maReference<<"ans.(via reference)"<<endl;    //Et on affiche en utilisant la r�f�rence

    /***********PRESENTATION***********/
    string  pi("-1");

    cout<<"Quel est votre nom: ";
    string nomUtilisateur("sansNom");
    cin>>nomUtilisateur;
    //getline(cin,nomUtilisateur);//getline permet de r�cuperer toute la ligne meme avec les espaces
    cout<<endl;
    cout<<"Combien vaut pi? ";
    cin>>pi;
    cout<<endl;
    cout<<"Vous vous appelez "<<nomUtilisateur<<" et vous pensez que pi vaut: "<<pi<<endl;
    cout<<"Votre prenom contient"<<nomUtilisateur.size()<<"lettres."<<endl;
    nomUtilisateur.push_back('a');
    cout<<"Je viens d'ajouter 'a' a votre nom qui est d�sormais "<<nomUtilisateur<<"."<<endl;

    /******************Fichier Repartis************************/
    double nombre(5);
    ajouteDeux(nombre);
    cout<<endl;

    /***********TABLEAU*******************/
    int const nmbrescores(5);
    double  scores[nmbrescores];
    array <float , 20> autre_tableau;//autre type de declaration
    int i;
    double moy;

    scores[0]=10000;
    scores[1]=9500;
    scores[2]=8000;
    scores[3]=7800;
    scores[4]=7400;

    cout<<"Voici les 5 meilleurs scores de notre jeu:"<<endl;
    for(i=0; i<5; i++)
    {
        cout<<scores[i]<<" ";
    }

    moy=moyenne(scores,nmbrescores);
    cout<<"La moyenne des scores est: "<<moy;

    /**************TABLEAU DYNAMIQUE***********/
     vector<int> tableau(5); // tableau dynamique
          /*vector<int> tableau(5, 3); Cr�e un tableau de 5 entiers valant tous 3
            vector<string> listeNoms(12,"Sans nom");Cr�e un tableau de 12 strings valant toutes � Sans nom�*/

            vector<int> tabl(3,2); //Un tableau de 3 entiers valant tous 2
            tabl.push_back(8); //On ajoute une 4�me case qui contient la valeur 8
            //tableau.pop_back();//Et  hop! Plus que 2 cases
            //Pour en apprendre plus sur les tableaux, voir cours open classroom

            //Une fonction recevant un tableau d'entiers en argument
         /*
            void fonction(vector<int> const& a)
            {
            //�
            }
        */



            /****************LECTURE ET ECRITURE DANS LES FICHIERS*******************/
             string const nomFichier("D:/New/scores.txt");
             ofstream monFlux(nomFichier.c_str());// ou  ofstream monFlux( " D:/New/scores.txt");
             //D�claration d'un flux permettant d'�crire dans le fichier//C:/New/scores.txt
            /*
            Pour pouvoir �crire � la fin d'un fichier sans supprimer son contenu, il faut le sp�cifier lors de l'ouverture en
            ajoutant un deuxi�me param�tre � la cr�ation du flux: ofstream monFlux("D:/New/scores.txt",ios::app);.
             */


            if(monFlux) //On teste si tout est OK
            {
                    monFlux<<"Bonjour,je suis une phrase �crite dans un fichier."<<endl;
                    monFlux<<42.1337<<endl;
                    int age(19);
                    monFlux<<"J'ai"<<age<<"ans."<<endl;

            }
            else
            {
                    cout<<"ERREUR:Impossible d'ouvrir le fichier."<<endl;
            }

            ifstream monFlu("D:/New/scores.txt");//Ouverture d'un fichier en lecture

            if(monFlu)
            {
               //L'ouverture s'est bien pass�e, on peut donc lire
              string ligne; //Une variable pour stocker les lignes lues
             while(getline(monFlu,ligne))//Tant qu'on n'est pas � la fin, on lit
              {
                 cout<<ligne<<endl;
                 //Et on l'affiche dans la console
                 //Ou alors on fait quelque chose avec cette ligne
                 //� vous de voir
              }

            }
            else
            {
                cout<<"ERREUR:Impossible d'ouvrir le fichier en lecture."<<endl;
            }

    return 0;
}
