#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    char lettre='A'; //Le type char permet de stocker UNE seule lettre.
    printf("%d\n",lettre);//Retourne le nombre correspondant � la lettre A car la memoire ne peut conserver que des nombres
    printf("%c\n",lettre);// Retourne la lettre le langage C permettant de faire la correspondance lettre-nombre grace � la table ASCII

    char let=0;
    printf("Entrez UNE lettre:\n");
    scanf("%c",&let);//On demande � l'utilisateur d'entrer UNE lettre
    printf("%c\n",let);//On affiche la lettre
    // Pour stocker du texte nous allons utilser les tbleaux

    char chaine[6]; // Tableau de 6 char pour stocker S-a-l-u-t + le \0 (\0: symbole marquant la fin d'une chaine de caractere

    chaine[0] = 'S';
    chaine[1] = 'a';
    chaine[2] = 'l';
    chaine[3] = 'u';
    chaine[4] = 't';
    chaine[5] = '\0';printf("%s\n",chaine);

  /*Cette m�thode marche.On peut le v�rifier avec un printf en utilisant le symbole %s(s pour string en anglais, qu'on traduit
  par "cha�ne").Vous remarquerez que c'est un peu fatigant et r�p�titif de devoir
  �crire les caract�res un � un comme on l'a fait dans le tableau chaine  .
 Pour initialiser une cha�ne, il existe heureusement une m�thode plus simple :*/
    char chaines[] = "Salut"; // La taille du tableau chaine est automatiquement calcul�e
    printf("%s", chaines); printf("\n");
/*Il y a toutefois un d�faut : �a ne marche que pour l'initialisation ! Vous ne pouvez pas �crire plus loin dans le code :
chaine = "Salut";
Cette technique est donc � r�server � l'initialisation. Apr�s cela, il faudra �crire les caract�res manuellement
un � un en m�moire, comme on l'a fait au d�but.*/


/*R�cup�rez une cha�ne via un scanf
Vous pouvez enregistrer une cha�ne entr�e par l'utilisateur via un scanf  , via le symbole %s  .
Seul probl�me : vous ne savez pas combien de caract�res l'utilisateur va entrer. Si vous lui demandez son pr�nom,
 il s'appelle peut-�tre Luc (3 caract�res), mais qui vous dit qu'il ne s'appelle pas Jean-�douard (beaucoup plus de caract�res) ?
Pour �a, il n'y a pas 36 solutions. Il va falloir cr�er un tableau de char suffisamment grand pour pouvoir stocker le pr�nom.
 On va donc cr�er un char[100] :*/
 char prenom[100];
 printf("Quel ton prenom?\n");
 scanf("%s",&prenom);
 printf("Salut %s. Je suis heureux de te rencontrer.",prenom);


 /*Manipulez des cha�nes � l'aide de fonctions
La biblioth�que string.h fournit de nombreuses fonctions d�di�es aux calculs sur des cha�nes.

Je vais vous pr�senter les principales :

strlen pour calculer la longueur d'une cha�ne.

strcpy pour copier une cha�ne dans une autre.

strcat pour concat�ner 2 cha�nes.

strcmp pour comparer 2 cha�nes.

strchr pour rechercher un caract�re.

strpbrk pour rechercher le premier caract�re de la liste.

strstr pour rechercher une cha�ne dans une autre.

sprintf pour �crire dans une cha�ne.

Comme on va utiliser une nouvelle biblioth�que appel�e string.h  , vous devez l'inclure !*/
int longueur;
longueur=strlen(prenom);
printf("Ton prenom a %d lettres. \n",longueur);


 /* On cr�e une cha�ne "chaine" qui contient un peu de texte
    et une copie (vide) de taille 100 pour �tre s�r d'avoir la place
    pour la copie */

    char chain[] = "Texte", copie[100] = {0};

    strcpy(copie, chain); // On copie "chain" dans "copie"

    // Si tout s'est bien pass�, la copie devrait �tre identique � chaine
    printf("chain vaut : %s\n", chain);
    printf("copie vaut : %s\n", copie);


     /* On cr�e 2 cha�nes. chaine1 doit �tre assez grande pour accueillir
    le contenu de chaine2 en plus, sinon risque de plantage */
    char chaine1[100] = "Salut ", chaine2[] = "Mateo21";

    strcat(chaine1, chaine2); // On concat�ne chaine2 dans chaine1

    // Si tout s'est bien pass�, chaine1 vaut "Salut Mateo21"
    printf("chaine1 vaut : %s\n", chaine1);
    // chaine2 n'a pas chang� :
    printf("chaine2 vaut toujours : %s\n", chaine2);


    char chain1[] = "Texte de test", chain2[] = "Texte de teste";

    if (strcmp(chain1, chain2) == 0) // Si cha�nes identiques
    {
        printf("Les chaines sont identiques\n");
    }
    else
    {
        printf("Les chaines sont differentes\n");
    }


    char chain3[] = "Texte de test", *suiteChaine = NULL;

    suiteChaine = strchr(chain3, 'd');
    if (suiteChaine != NULL) // Si on a trouv� quelque chose
    {
        printf("Voici la fin de la chaine a partir du premier d : %s", suiteChaine);
    }
    //Il existe une fonction strrchr strictement identique � strchr  , sauf que celle-l� renvoie un pointeur vers
    //le dernier caract�re qu'elle a trouv� dans la cha�ne, plut�t que vers le premier.

    //Pour en apprendre plus et en detail, rendez-vous sur openclassroom.com

            return 0;
}
