#ifndef PERSONNAGE_H_INCLUDED
#define PERSONNAGE_H_INCLUDED
#define DEF_PERSONNAGE
#include <string>
#include "Arme.h" //Ne PAS oublier d'inclure Arme.h pour en avoir la d�finition



class Personnage
{
    public:
    Personnage();
    Personnage(std::string nomArme, int degatsArme);
    ~Personnage();

    void recevoirDegats(int nbDegats, std::string nomJoueur);
    void attaquer(Personnage &cible, std::string nomJoueur);
    void boirePotionDeVie(int quantitePotion);
    int  getmana() const;
    void changerMana(int nbr);
    void faireMagie(Personnage &cible, int nbrDegats, int coutMana, std::string nomJoueur);
    void changerArme(std::string nomNouvelleArme, int degatsNouvelleArme);
    bool estVivant() const;
    void afficherEtat() const;

    private:
    int m_vie;
    int m_mana;
   // std::string m_nomArme;//Pas de using namespace std,il faut donc mettre std::devant string
    Arme m_arme; //Notre Personnage poss�de une Arme.La classe Arme est associ�e � la classe personnage



} ;



#endif // PERSONNAGE_H_INCLUDED
