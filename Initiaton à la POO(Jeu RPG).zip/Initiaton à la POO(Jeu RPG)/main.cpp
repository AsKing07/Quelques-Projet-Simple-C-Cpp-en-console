#include <iostream>
#include <string>
#include "Personnage.h"

using namespace std;






int main()
{
    string joueur1, joueur2;

    cout<<"Bienvenue dans le jeu RPG 'Combat des titans"<<endl;
    cout <<"Joueur 1 veuillez entrer votre nom: ";
    cin>>joueur1;
    cout <<"Joueur 2 veuillez entrer votre nom: ";
    cin>>joueur2;

   //Cr�ation des personnages (objets)
    Personnage Personnage1, Personnage2; //Cr�ation de 2 objets de type Personnage
   // Personnage samson(Personnage1); On cr�e samson en copiant tous les attributs de Personnage1 grace au constructeur de copie
   //Personnage2("epee aiguisee", 20); On cr�e un personnage avec l'arme epee aiguis�e et de d�gats 20

   //Au combat
    while(Personnage2.estVivant() && Personnage1.estVivant())
    {
         int sortie1(0);
         while(sortie1==0 )
      {

                int choix1(0);

                  cout<<"C'est au tour du joueur 1"<<endl;


                  while(choix1<1 || choix1>4)
                  {
                      cout<<joueur1<<" Que diserez vous faire?"<<endl<<"1-Attaquer"<<endl<<"3-Boire une potion de vie(Regeneration de 20 points"<<endl<<"3-Faire de la magie"<<endl<<"4-Changer d'arme"<<endl;
                      cin>>choix1;
                    switch(choix1)
                    {
                        case 1:
                            {

                                cout<<joueur1<<" attaque "<<joueur2<<endl;
                                Personnage1.attaquer(Personnage2,joueur2);   //Joueur1  attaque Joueur2

                                cout <<endl << joueur2 << endl;
                                Personnage2.afficherEtat();
                                sortie1=1;
                                break;

                            }

                        case 2:

                            {


                            cout<<joueur1<<" boit une potion de vie et se regenere 20 points de vie."<<endl;
                            Personnage1.boirePotionDeVie(20); //Joueur1 r�cup�re 20 de vie en buvant une  potion
                            cout << joueur1 << endl;
                            Personnage1.afficherEtat();
                            sortie1=1;

                            break;

                            }

                        case 3:
                            {


                                    int choixmagie1(0);
                                     while(choixmagie1<1 || choixmagie1>3)
                                    {
                                        cout<<"Quelle magie voulez-vous faire?"<<endl;
                                        cout<<"1- Boule de feu : Degats: 30;  Cout en mana:40 mana"<<endl;
                                        cout<<"2- Dragon d'eau : Degats: 20;  Cout en mana:25 mana"<<endl;
                                        cout<<"3- Poison : Degats: 10;  Cout en mana:15 mana"<<endl;
                                        cin>>choixmagie1;
                                        if(choixmagie1<1 || choixmagie1>3)
                                            {
                                               cout<<"Veuillez reverifier votre choix."<<endl;
                                            }
                                     }



                                      switch(choixmagie1)
                                      {
                                            case 1:
                                                {

                                                    if(Personnage1.getmana()>40)
                                                    {
                                                        Personnage1.faireMagie(Personnage2, 30, 40,joueur2 );
                                                        sortie1=1;
                                                        cout<<joueur1<<" lance la boule de feu supreme!!! "<<endl;
                                                        cout <<endl << joueur2 << endl;
                                                        Personnage2.afficherEtat();
                                                    }
                                                    else
                                                    {
                                                        cout<<"Attaque impossible. Mana insuffisant!!!"<<endl;
                                                    }
                                                    break;
                                                }

                                            case 2:
                                                {


                                                    if(Personnage1.getmana()>25)
                                                    {
                                                        Personnage1.faireMagie(Personnage2, 20, 25,joueur2 );
                                                        sortie1=1;
                                                        cout<<joueur1<<" invoque le drago  aqueu!!! "<<endl;
                                                        cout <<endl << joueur2 << endl;
                                                        Personnage2.afficherEtat();
                                                    }
                                                    else
                                                    {
                                                        cout<<"Attaque impossible. Mana insuffisant!!!"<<endl;
                                                    }
                                                    break;

                                                 }

                                            case 3:
                                                {


                                                    if(Personnage1.getmana()>15)
                                                    {

                                                        Personnage1.faireMagie(Personnage2, 10, 15,joueur2 );
                                                        sortie1=1;
                                                        cout<<joueur1<<" utilise du poison! "<<endl;
                                                        cout <<endl << joueur2 << endl;
                                                        Personnage2.afficherEtat();
                                                    }
                                                    else
                                                    {
                                                        cout<<"Attaque impossible. Mana insuffisant!!!"<<endl;
                                                    }
                                                    break;

                                                }

                                            default:
                                                {


                                                    cout<<"Veuillez reverifier votre choix."<<endl;
                                                    break;

                                                }
                                      }

                                    break;
                            }



                        case 4:
                          {


                            int choixarme1(0);

                            cout<<"Quelle arme voulez-vous choisir?"<<endl;
                            cout<<"1- Epee classique : Degats: 10;  Cout en mana:0 mana"<<endl;
                            cout<<"2- Epee aiguisee : Degats: 20;  Cout en mana:20 mana"<<endl;
                            cout<<"3- Hache legendaire : Degats: 35;  Cout en mana: 40 mana"<<endl;
                            cout<<"4- Escalibur : Degats: 45;  Cout en mana: 50 mana"<<endl;
                            cin>>choixarme1;
                            while(choixarme1<1 || choixarme1>4)
                            {


                              switch(choixarme1)
                              {
                                    case 1:
                                        {


                                            if(Personnage1.getmana()>0)
                                            {
                                                Personnage1.changerArme("Epee rouillee",10);
                                                Personnage1.changerMana(0);
                                                sortie1=1;
                                            }
                                            else
                                            {
                                                cout<<"Changement impossible. Mana insuffisant!!!"<<endl;
                                            }
                                            break;
                                        }

                                    case 2:
                                        {


                                            if(Personnage1.getmana()>20)
                                            {
                                                Personnage1.changerArme("Epee aiguisee",35);
                                                Personnage1.changerMana(20);
                                                sortie1=1;
                                            }
                                            else
                                            {
                                                cout<<"Changement impossible. Mana insuffisant!!!"<<endl;
                                            }
                                            break;
                                         }

                                    case 3:
                                        {


                                            if(Personnage1.getmana()>40)
                                            {
                                                Personnage1.changerArme("Hache legendaire",35);
                                                Personnage1.changerMana(40);
                                                sortie1=1;
                                            }
                                            else
                                            {
                                                cout<<"Changement impossible. Mana insuffisant!!!"<<endl;
                                            }
                                            break;
                                        }

                                     case 4:
                                         {


                                            if(Personnage1.getmana()>50)
                                            {
                                                Personnage1.changerArme("Escalibure",45);
                                                Personnage1.changerMana(50);
                                                sortie1=1;
                                            }
                                            else
                                            {
                                                cout<<"Changement impossible. Mana insuffisant!!!"<<endl;
                                            }
                                            break;
                                        }

                                    default:
                                        {


                                            cout<<"Veuillez reverifier votre choix."<<endl;
                                            break;

                                        }
                              }
                            }
                            break;
                         }

                                     default:
                                         {

                                         cout<<"Veuillez reverifier votre choix."<<endl;
                                         break;

                                         }

                    }
            }


      }
             int sortie2(0);
         while(sortie2==0)
      {

                int  choix2(0);

                  cout<<endl<<"C'est au tour du joueur 2"<<endl;


                  while(choix2<1 || choix2>4)
                  {
                      cout<<joueur2<<" Que diserez vous faire?"<<endl<<"1-Attaquer"<<endl<<"3-Boire une potion de vie(Regeneration de 20 points)"<<endl<<"3-Faire de la magie"<<endl<<"4-Changer d'arme"<<endl;
                       cin>>choix2;
                    switch(choix2)
                    {
                        case 1:
                            {

                            cout<<joueur2<<" attaque "<<joueur1<<endl;
                            Personnage2.attaquer(Personnage1,joueur1);   //Joueur1  attaque Joueur2
                            Personnage1.afficherEtat();
                            sortie2=1;
                            break;

                            }

                        case 2:

                            {


                            cout<<joueur2<<" boit une potion de vie et se regenere 20 points de vie."<<endl;
                            Personnage2.boirePotionDeVie(20); //Joueur1 r�cup�re 20 de vie en buvant une  potion
                            cout << joueur2 << endl;
                            Personnage2.afficherEtat();
                            sortie2=1;
                            break;

                            }

                        case 3:
                            {


                                    int choixmagie2(0);
                                     while(choixmagie2<1 || choixmagie2>3)
                                    {
                                        cout<<"Quelle magie voulez-vous faire?"<<endl;
                                        cout<<"1- Boule de feu : Degats: 30;  Cout en mana:40 mana"<<endl;
                                        cout<<"2- Dragon d'eau : Degats: 20;  Cout en mana:25 mana"<<endl;
                                        cout<<"3- Poison : Degats: 10;  Cout en mana:15 mana"<<endl;
                                        cin>>choixmagie2;
                                        if(choixmagie2<1 || choixmagie2>3)
                                        {
                                           cout<<"Veuillez reverifier votre choix."<<endl;
                                        }
                                    }



                                      switch(choixmagie2)
                                      {
                                            case 1:
                                                {

                                                    if(Personnage2.getmana()>40)
                                                    {
                                                        Personnage2.faireMagie(Personnage1, 30, 40,joueur1 );
                                                        sortie2=1;
                                                        cout<<joueur2<<" lance la boule de feu supreme!!!!" <<endl;
                                                        cout <<endl << joueur1 << endl;
                                                        Personnage1.afficherEtat();
                                                    }
                                                    else
                                                    {
                                                        cout<<"Attaque impossible. Mana insuffisant!!!"<<endl;
                                                    }
                                                    break;
                                                }

                                            case 2:
                                                {


                                                    if(Personnage2.getmana()>25)
                                                    {
                                                        Personnage2.faireMagie(Personnage1, 20, 25,joueur1 );
                                                        sortie2=1;
                                                        cout<<joueur2<<" invoque le dragon aqueu!!!!" <<endl;
                                                        cout <<endl << joueur1 << endl;
                                                        Personnage1.afficherEtat();
                                                    }
                                                    else
                                                    {
                                                        cout<<"Attaque impossible. Mana insuffisant!!!"<<endl;
                                                    }
                                                    break;

                                                 }

                                            case 3:
                                                {


                                                    if(Personnage2.getmana()>15)
                                                    {
                                                        Personnage2.faireMagie(Personnage1, 10, 15,joueur1 );
                                                        sortie2=1;
                                                        cout<<joueur2<<" utilise du poison!!" <<endl;
                                                        cout <<endl << joueur1 << endl;
                                                        Personnage1.afficherEtat();
                                                    }
                                                    else
                                                    {
                                                        cout<<"Attaque impossible. Mana insuffisant!!!"<<endl;
                                                    }
                                                    break;

                                                }

                                            default:
                                                {


                                                    cout<<"Veuillez reverifier votre choix."<<endl;
                                                    break;

                                                }
                                      }

                                    break;
                            }



                        case 4:
                          {


                            int choixarme2(0);

                            cout<<"Quelle arme voulez-vous choisir?"<<endl;
                            cout<<"1- Epee classique : Degats: 10;  Cout en mana:0 mana"<<endl;
                            cout<<"2- Epee aiguisee : Degats: 20;  Cout en mana:20 mana"<<endl;
                            cout<<"3- Hache legendaire : Degats: 35;  Cout en mana: 40 mana"<<endl;
                            cout<<"4- Escalibur : Degats: 45;  Cout en mana: 50 mana"<<endl;
                            cin>>choixarme2;
                            while(choixarme2<1 || choixarme2>4)
                            {


                              switch(choixarme2)
                              {
                                    case 1:
                                        {


                                            if(Personnage2.getmana()>0)
                                            {
                                                Personnage2.changerArme("Epee rouillee",10);
                                                Personnage2.changerMana(0);
                                                sortie2=1;
                                            }
                                            else
                                            {
                                                cout<<"Changement impossible. Mana insuffisant!!!"<<endl;
                                            }
                                            break;
                                        }

                                    case 2:
                                        {


                                            if(Personnage2.getmana()>20)
                                            {
                                                Personnage2.changerArme("Epee aiguisee",35);
                                                Personnage2.changerMana(20);
                                                sortie2=1;
                                            }
                                            else
                                            {
                                                cout<<"Changement impossible. Mana insuffisant!!!"<<endl;
                                            }
                                            break;
                                         }

                                    case 3:
                                        {


                                            if(Personnage2.getmana()>40)
                                            {
                                                Personnage2.changerArme("Hache legendaire",35);
                                                Personnage2.changerMana(40);
                                                sortie2=1;
                                            }
                                            else
                                            {
                                                cout<<"Changement impossible. Mana insuffisant!!!"<<endl;
                                            }
                                            break;
                                        }

                                     case 4:
                                         {


                                            if(Personnage2.getmana()>50)
                                            {
                                                Personnage2.changerArme("Escalibure",45);
                                                Personnage2.changerMana(50);
                                                sortie2=1;
                                            }
                                            else
                                            {
                                                cout<<"Changement impossible. Mana insuffisant!!!"<<endl;
                                            }
                                            break;
                                        }

                                    default:
                                        {


                                            cout<<"Veuillez reverifier votre choix."<<endl;
                                            break;

                                        }
                              }
                            }
                            break;
                         }

                                     default:
                                        {

                                             cout<<"Veuillez reverifier votre choix."<<endl;
                                             break;

                                        }

                    }
            }




          }

          cout<<endl;

      }


            if(Personnage1.estVivant()==false)
            {
                cout<< joueur1<<" a perdu"<<endl;
            }
            else if (Personnage2.estVivant()==false)
            {
                cout<< joueur2<<" a perdu"<<endl;
            }
            else
            {
                cout<<"Match Nul"<<endl;
            }





      /*  Personnage1.attaquer(Personnage2,joueur2);   //goliath attaque david
        Personnage2.boirePotionDeVie(20); //david r�cup�re 20 de vie en buvant une  potion
        Personnage1.attaquer(Personnage2, joueur2);   //goliath  r�attaque david
        Personnage2.attaquer(Personnage1, joueur1);   //david contre-attaque...c'est assez clair non ?

        Personnage1.changerArme("Double hache tranchante veneneuse de la mort", 40);
        Personnage1.attaquer(Personnage2, joueur2);

        //Temps mort ! Voyons voir la vie de chacun...
        cout << joueur1 << endl;
        Personnage1.afficherEtat();
        cout <<endl << joueur2 << endl;
        Personnage2.afficherEtat();
        */






    return 0;
}

