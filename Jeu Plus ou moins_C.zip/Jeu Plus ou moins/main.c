#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int nmbrMystere=0, nmbrEntre;
    const int Max=100, Min=1;
    srand(time(NULL));
    nmbrMystere = (rand() % (Max - Min + 1)) + Min;
    do
    {
        printf("Tente de deviner le nombre mystere en entrant un nombre:\n");
        scanf("%d", &nmbrEntre);
        if(nmbrEntre<nmbrMystere)
        {
            printf("Le nombre mystere est encore plus grand.\n");
        }
        else if (nmbrEntre>nmbrMystere)
        {
            printf("Le nombre mystere est encore plus petit.\n");
        }
        else
        {
            printf("Bravo vous avez reussi!!!!!!");
        }
    }
    while(nmbrEntre!=nmbrMystere);
    return 0;
}
