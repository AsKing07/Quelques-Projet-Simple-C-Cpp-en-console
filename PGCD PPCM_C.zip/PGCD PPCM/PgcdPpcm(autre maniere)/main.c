
int main()
{
    int n1,n2,i,pgcd;
    printf("Entrez le premier nombre:\n");
    scanf("%d",&n1);
    printf("Entrez le deuxieme nombre:\n");
    scanf("%d",&n2);
    for(i=1; i<=n1 && i<=n2; i++)
    {
        if(n1%i==0 && n2%i==0)
        {
            pgcd=i;
        }
    }
    printf("Le pgcd est %d et le ppcm est %d.\n",pgcd,n1*n2/pgcd);
    return 0;
}
