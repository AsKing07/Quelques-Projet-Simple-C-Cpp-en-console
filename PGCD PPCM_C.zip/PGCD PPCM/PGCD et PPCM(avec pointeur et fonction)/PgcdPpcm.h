#ifndef PGCDPPCM_H_INCLUDED
#define PGCDPPCM_H_INCLUDED

void PgcdPpcm(int* nmbr1, int* nmbr2);

#endif // PGCDPPCM_H_INCLUDED
