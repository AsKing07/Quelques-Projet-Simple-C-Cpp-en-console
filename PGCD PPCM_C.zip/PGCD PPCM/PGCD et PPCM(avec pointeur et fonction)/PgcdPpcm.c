#include "PgcdPpcm.h"
void PgcdPpcm(int* nmbr1, int* nmbr2)
{
    int tmp, r;
    if(*nmbr1<0)
    {
        *nmbr1=-(*nmbr1);
    }
    if(*nmbr2<0)
    {
        *nmbr2=-(*nmbr2);
    }
    if(*nmbr1==0)
    {
        *nmbr1= *nmbr2;
    }
    if(nmbr2==0)
    {
        *nmbr1=*nmbr1;
    }
    if (*nmbr1!=0 && *nmbr2!=0)
    {
        if (*nmbr1 < *nmbr2)
       {
        tmp=(*nmbr1);
        *nmbr1=(*nmbr2);
        *nmbr2=tmp;
       }
        do
            {
                r=(*nmbr1)%(*nmbr2);
                *nmbr1=(*nmbr2);
                *nmbr2=r;
            }
            while(r!=0);
    }
}
