#include <stdio.h>
#include <stdlib.h>
#include "PgcdPpcm.h"
int main()
{
    int nbr1,nbr2,tmp1,tmp2,pgcd;
    do
    {
      printf("Veuillez entrer le  numerateur:\n");
    scanf("%d", &nbr1);
    printf("Veuillez entrer le  denominateur:\n");
    scanf("%d", &nbr2);
    }while(nbr2==0);

    tmp1=nbr1;
    tmp2=nbr2;
    PgcdPpcm(&nbr1,&nbr2);
   if(tmp1>=0 && tmp2>=0)
   {
        printf ("Le PGCD des deux nombres est %d et leur PPCM est %d. \n",nbr1, (tmp1*tmp2)/nbr1);
   }
   if(tmp1<0 && tmp2>=0)
   {
        printf ("Le PGCD de %d et de %d est %d et leur PPCM est %d. \n",-tmp1,tmp2,nbr1,(-tmp1*tmp2)/nbr1);
   }
   if(tmp1>=0 && tmp2<0)
   {
        printf ("Le PGCD de %d et de %d est %d et leur PPCM est %d. \n",tmp1,-tmp2,nbr1,(tmp1*-tmp2)/nbr1);
   }
   if(tmp1<0 && tmp2<0)
   {
        printf ("Le PGCD de %d et de %d est %d et leur PPCM est %d. \n",-tmp1,-tmp2,nbr1,(-tmp1*-tmp2)/nbr1);
   }
     printf ("La fraction reduite est donc %d/%d \n",tmp1/nbr1, tmp2/nbr1);
    return 0;
}
