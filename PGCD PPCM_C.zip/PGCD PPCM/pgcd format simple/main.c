#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,r,tmp,c,d;
    printf("Entrez le premier nombre:\n");
    scanf("%d",&a);
    printf("Entrez le deuxieme nombre:\n");
    scanf("%d",&b);
    c=a;
    d=b;
    if(a==0 || b==0)
    {
        if(a==0)
        {
            printf("Le pgcd est %d et le ppcm est 0. \n",b);
            exit;
        }
        if(b==0)
        {
            printf("Le pgcd est %d et le ppcm est 0. \n",a);
            exit;
        }
    }
    if(a<b)
    {
      tmp=a;
      a=b;
      b=tmp;
    }
    do
    {
        r=a%b;
        a=b;
        b=r;
    }while(r!=0);
    c=c*d/a;


printf("Le pgcd est %d et le ppcm est %d.",a,c);
    return 0;

}
