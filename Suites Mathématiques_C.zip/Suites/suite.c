int geometrique(int *n)
{
    int i,e=1,Uo=1;
    for(i=1;i<=*n;i++)
    {
      e=3*e;
    }
    return Uo*e;
}
int arithmetique(int *n)
{
    int Uo=1;
    return ((7*(*n)+Uo));
}
int fibonnacci(int *n)
{
    int suivant,i,Uo=1,U1=1;
    for(i=0;i<=*n;i++)
    {
        if(i<=1)
        {
            suivant=i;
        }
        else
        {
            suivant=Uo+U1;
            Uo=U1;
            U1=suivant;
        }
    }
    return suivant;
}
