#ifndef SUITE_H_INCLUDED
#define SUITE_H_INCLUDED

int arithmetique (int* n);
int geometrique(int* n);
int fibonnacci(int* n);


#endif // SUITE_H_INCLUDED
