#include <stdio.h>
#include <stdlib.h>
#include "suite.h"

int main()
{
    int choix,n,resultat,exit;
    do
    {
    printf("Bienvenue sur notre programme. Nous vous proposons trois differentes suites.\n");
    printf("1-La suite Arithmetique definie par:\n Un=7+U(n-1)\n Uo=1  \n\n");
    printf("2-La suite Geometrique definie par:\n Un=3(Un-1)\n Uo=1 \n\n");
    printf("3-.La suite de Fibonacci defini par:\n Un=U(n-1)+U(n-2) \n\n");
    printf("Faites votre choix:\n");
    scanf("%d",&choix);
    if(choix>3 || choix<0)
    {
        printf("Veuillez reverifier votre choix.");
    }
     else
     {
         printf("Quel est l'indice du terme que vous voulez calculer?\n");
    scanf("%d",&n);
     }

    switch(choix)
    {
    case 1:
        resultat=arithmetique(&n);
        printf("U(%d)=%d.\n",n,resultat);
        break;
    case 2:
        resultat=geometrique(&n);
        printf("U(%d)=%d.\n",n,resultat);
        break;
    case 3:
        resultat=fibonnacci(&n);
        printf("U(%d)=%d.\n",n,resultat);
        break;
    }
      printf("Si vous voulez continuer appuyez sur 1 sinon appuyez sur 0\n");
      scanf("%d",&exit);
      system("cls");
     } while(exit==1);
    return 0;

}
