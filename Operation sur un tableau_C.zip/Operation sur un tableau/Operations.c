float moy(int tab[], int taille)
{
    int i;
    float som=0;

    for(i=0;i<taille;i++)
        {
          som=som+tab[i];
        }
    return(som/taille);
}

void parite(int tab[],int taille)
{
    int i;
    printf("Les elements pairs de votre tableau sont: ");
    for(i=0;i<taille;i++)
    {
            if((tab[i]%2)==0)
        {
            printf("%d ",tab[i]);
        }
    }
}
