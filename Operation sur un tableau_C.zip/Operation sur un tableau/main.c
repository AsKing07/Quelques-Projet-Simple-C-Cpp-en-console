#include <stdio.h>
#include <stdlib.h>
#include"Operations.h"

int main()
{
    float moyenne;
    int i,taille,tableau[500];
    char prenom[50];
    printf("Bonjour cher utilisateur. Veuillez entrer votre prenom.\n");
    scanf("%s",&prenom);
    printf("Bienvenue sur notre programme %s.Nous allons t'aider a calculer la moyenne de ton tableau.\n Entre la taille de ton taibleau.\n", prenom);
    scanf("%d",&taille);

    for(i=0;i<taille;i++)
    {
        printf("Tape l'element numero %d de ton tableau:  ",i+1);
        scanf("%d",&tableau[i]);
    }
    moyenne=moy(tableau,taille);
    printf("La moyenne de ton tableau est %f \n",moyenne);

    parite(tableau,taille);
    return 0;
}
