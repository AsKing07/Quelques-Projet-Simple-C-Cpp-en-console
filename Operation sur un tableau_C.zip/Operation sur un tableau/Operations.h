#ifndef OPERATIONS_SUR_LE_TABLEAU_H_INCLUDED
#define OPERATIONS_SUR_LE_TABLEAU_H_INCLUDED
float moy(float tab[], int taille);
void parite(int tab[],int taille);


#endif // OPERATIONS_SUR_LE_TABLEAU_H_INCLUDED
