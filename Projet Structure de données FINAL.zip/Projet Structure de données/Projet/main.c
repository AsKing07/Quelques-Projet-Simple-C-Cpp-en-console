#include <stdio.h>
#include <stdlib.h>


typedef void object;

// D�finition de la structure d'une cellule de la liste doublement chain�e
typedef struct CelluleDbl* PCelluleDbl;

typedef struct CelluleDbl {
    object* valeur;      // Pointeur vers l'objet stock� dans la cellule
    PCelluleDbl suivant; // Pointeur vers la cellule suivante dans la liste
    PCelluleDbl precedent; // Pointeur vers la cellule pr�c�dente dans la liste
} ListeDbl;

//Fonction de cr�ation de liste
void creerListeDbl(PCelluleDbl l, int n)
{
        // Cette fonction cr�e une liste doublement cha�n�e � partir d'une cellule donn�e et d'un nombre d'�l�ments donn�
        // D�clarations des variables locales
        PCelluleDbl tete, p;
        int i, donnee;

        // Demande � l'utilisateur d'entrer le premier �l�ment de la liste


        printf("Entrez le premier element \n");

         while (scanf("%d", &donnee) != 1)//permet de s'assurer que l'utilisateur entre un nombre entier
    {
        printf("Erreur: Veuillez entrer un nombre entier : ");
        while (getchar() != '\n'); // Clear the input buffer
    }

        // Initialisation de la cellule t�te de la liste
        tete=l;
        tete->valeur=donnee;
        tete->suivant=NULL;
        tete->precedent=NULL;

        // Boucle pour ajouter les �l�ments suivants � la liste
        for(i=2;i<=n;i++)
        {
            p=malloc(sizeof(PCelluleDbl));// Alloue de l'espace pour la cellule � ajouter
            printf("Entrez l'element numero %d: \n", i);// Demande � l'utilisateur d'entrer l'�l�ment suivant de la liste
            while (scanf("%d", &donnee) != 1)//permet de s'assurer que l'utilisateur entre un nombre entier
            {
                printf("Erreur: Veuillez entrer un nombre entier : ");
                while (getchar() != '\n'); // Clear the input buffer
            }

            // Initialise les champs de la nouvelle cellule
            p->valeur=donnee;
            p->suivant=NULL;
            p->precedent=tete;

            // Ajoute la nouvelle cellule � la fin de la liste
            tete->suivant=p;
            tete=p;
        }
}


//Affichage de la liste
void afficherListe(PCelluleDbl l)
{
    // Cette fonction affiche la liste � partir de la cellule en entr�e
        printf("Voici votre liste: \n"); // Affiche un message pour indiquer que la liste va �tre affich�e
        PCelluleDbl p;
        p=l;
        while(p!=NULL) // Tant qu'on n'est pas arriv� � la fin de la liste (cellule suivante est non-nulle)
        {
            printf("%d ",p->valeur); // Affiche la valeur de la cellule courante
            p=p->suivant; // Passe � la cellule suivante
        }
            printf("\n"); // Saut de ligne pour plus de lisibilit�

}


//Ajouter un �l�ment en tete de liste
PCelluleDbl ajoutertete(PCelluleDbl l)
{
    //Cette fonction prend en param�tre un pointeur sur la premi�re cellule de la liste et retourne un pointeur sur la nouvelle premi�re cellule de la liste.

    PCelluleDbl p;//Creation d'une nouvelle celle
    int donnee;//D�claration d'une variable pour stocker la valeur de la nouvelle cellule.
    printf("\n Entrer l'element a ajouter en tete \n");
      while (scanf("%d", &donnee) != 1)//permet de s'assurer que l'utilisateur entre un nombre entier
        {
            printf("Erreur: Veuillez entrer un nombre entier : ");
            while (getchar() != '\n'); // Clear the input buffer
        }
    p=malloc(sizeof(PCelluleDbl));//Allocation d'espace
    p->valeur=donnee;//Affectation de la valeur entr�e par l'utilisateur � la nouvelle cellule de la liste.
    p->precedent=NULL;//Initialisation du pointeur vers la cellule pr�c�dente � NULL, car la nouvelle cellule sera en t�te de liste.
    p->suivant=l;//La nouvelle cellule pointera vers l'ancienne premi�re cellule de la liste.
    l->precedent=p;
    return p;//La fonction retourne un pointeur sur la nouvelle premi�re cellule de la liste.

}

void ajouterQueue(PCelluleDbl l, int donnee)
{
    //D�claration d'une nouvelle cellule doublement cha�n�e "p" initialis�e � la valeur de la liste en param�tre
    PCelluleDbl p;
    p = l;
    //int donnee;

    //On parcourt la liste jusqu'� la fin en cherchant la derni�re cellule
    while(p->suivant != NULL)
    {
        p = p->suivant;
    }


    // Cr�ation d'une nouvelle cellule pour contenir l'�l�ment � ajouter avec allocation de m�moire
    PCelluleDbl nvelle_cell = malloc(sizeof(PCelluleDbl));

    nvelle_cell->valeur=donnee;//Affectation de la valeur � la nouvelle cellule

    //Initialisation des pointeurs suivant et pr�c�dent de la nouvelle cellule
    nvelle_cell->suivant = NULL;
    nvelle_cell->precedent = p;

    //Lien entre la derni�re cellule de la liste et la nouvelle cellule cr��e
    p->suivant = nvelle_cell;
}


void triBulle(PCelluleDbl l)
{
    int permut,temp;
    PCelluleDbl p, q;

    // On r�p�te la boucle tant qu'il y a eu des permutations dans le tableau
    do
    {
        // On commence � trier la liste depuis la t�te
        p=l;
        permut=0;

        while(p != NULL)// On parcourt chaque �l�ment de la liste
        {
            // On compare chaque �l�ment restant de la liste avec l'�l�ment courant
            q = p->suivant;
            while(q != NULL)
            {
                // Si l'�l�ment courant est plus grand que l'�l�ment suivant, on �change leurs valeurs
                if(p->valeur > q->valeur)
                {
                    permut=1;
                    temp = p->valeur;
                    p->valeur = q->valeur;
                    q->valeur = temp;
                }
                 // On passe � l'�l�ment suivant
                q = q->suivant;
            }
             // On passe � l'�l�ment suivant
            p=p->suivant;
        }

    }while(permut == 1);// On r�p�te la boucle tant qu'il y a eu des permutations dans le tableau
}



int rechercherElem(PCelluleDbl l,object* valeurRecherche, PCelluleDbl* addrRecherche)
{
    /* La fonction prend trois arguments en entr�e: un pointeur sur la premi�re cellule d'une liste doublement chain�e, un pointeur sur un objet dont on veut chercher la valeur dans la liste, et un pointeur sur une variable de type PCelluleDbl qui sera utilis�e pour stocker l'adresse de la cellule contenant la valeur recherch�e.*/

    //On d�clare des variables de type PCelluleDbl (pointeurs sur cellules) et un entier.
    PCelluleDbl p;
    int trouver=0;
    p=l;//On initialise la variable p � l'adresse de la premi�re cellule de la liste.


    while(trouver==0 && p!=NULL)//une boucle while qui continue tant qu'on n'a pas trouv� la valeur recherch�e et qu'on n'a pas atteint la fin de la liste.
    {
        //Dans la boucle, on compare la valeur de l'objet recherch� avec la valeur de la cellule point�e par p.
        if(p->valeur==valeurRecherche)//Si les deux valeurs sont �gales, on modifie la valeur de la variable trouver � 1 et on stocke l'adresse de la cellule dans la variable point�e par addrRecherche.
        {
            trouver=1;
            *addrRecherche=p;

        }

        p=p->suivant;//Sinon, on avance dans la liste en faisant pointer p vers la cellule suivante.
    }

    //Si on sort de la boucle while sans avoir trouv� la valeur, la fonction renvoie 0, sinon elle renvoie 1.
    return trouver;
}

//Supprimer un element specifique
PCelluleDbl supprimerElem(PCelluleDbl l, object* donnee)//D�finition de la fonction supprimerElem qui prend en entr�e un pointeur vers une liste cha�n�e l et un pointeur vers un objet donnee � supprimer
 {

    /*D�claration et initialisation des variables locales.
    adrrDeSupp est le pointeur vers la cellule � supprimer,
    preced est le pointeur vers la cellule pr�c�dente � adrrDeSupp,
    q est une variable temporaire pour parcourir la liste.
    n est un compteur pour le nombre total de cellules dans la liste,
    i est un compteur pour l'it�ration de la boucle,
    occurence est un compteur pour le nombre de fois que l'objet donnee a �t� trouv� et supprim�.*/

    PCelluleDbl adrrDeSupp=NULL, preced=NULL, q;
    int n=1,i,occurence=0;

    q=l;
    while (q->suivant!=NULL)//Parcours de la liste pour d�terminer le nombre total de cellules.
    {
        q=q->suivant;
        n=n+1;
    }


    for(i=0;i<n;i++)//Parcours de la liste pour rechercher toutes les occurrences de la donnee � supprimer.
    {
            if(l->valeur==donnee)// Si la premi�re cellule contient donnee, elle est supprim�e et la fonction continue � chercher d'autres occurrences de donnee.
                {
                    adrrDeSupp=l;
                    l=l->suivant;
                    if(l!=NULL)
                    {
                        l->precedent=NULL;
                        free(adrrDeSupp);
                    }
                     occurence++;
                }
            else//Sinon
                {

                    int recherche;
                    recherche=rechercherElem(l,donnee, &adrrDeSupp);//Sinon, la fonction recherche toutes les autres occurrences de donnee dans la liste.
                    if(recherche==1)// Si une cellule contient donnee, elle est supprim�e.
                    {
                        preced=adrrDeSupp->precedent;
                        preced->suivant=adrrDeSupp->suivant;
                        if(adrrDeSupp->suivant!=NULL)
                        {
                            adrrDeSupp->suivant->precedent=preced;
                        }
                        free(adrrDeSupp);
                        occurence++;
                    }

                }

    }

     //Affichage d'un message pour indiquer si l'objet donnee a �t� trouv� et supprim�.
     if(occurence==0)
     {
            system("clear || cls");
            printf("Cet element n'existe pas ");

     }
    else
     {
            system("clear || cls");
            printf("Suppression de %d occurence(s) de '%d' reussie.\n", occurence, donnee);
     }

     //Retourne un pointeur vers la liste cha�n�e mise � jour.
     return l;

}

//Supprimer les doublons
PCelluleDbl supprimerDoublonsDbl(PCelluleDbl l)
{
    PCelluleDbl p,q;
    if(l != NULL)
    {
        triBulle(l);//trier la liste avant la suppression des doublons pour faciliter l'op�ration


        p=l;
        while(p->suivant != NULL)
        {
            q=p->suivant;//q pointe vers l'element qui suit p
            while(p->valeur==q->valeur)// tant que les valeurs des cellules sont �gales
            {
               p->suivant=q->suivant;//// on supprime la cellule doublon en reliant la cellule pr�c�dente � la suivante de la cellule doublon


                if(q->suivant != NULL)
                {
                    q->suivant->precedent=p;// si on a supprim� une cellule, il faut reconnecter les cellules pr�c�dente et suivante
                }

                free(q);// on lib�re la m�moire de la cellule doublon
                q=p->suivant;// on passe � la cellule suivante

                if(q==NULL)// si la derni�re cellule a �t� supprim�e, on renvoie la liste
                {
                    return l;
                }

             }
                    p=p->suivant;

        }
    }
        return l;// on renvoie la liste sans doublons
}

//Supprimer dernier element
PCelluleDbl supprimerDerEle(PCelluleDbl l)
{
    //On v�rifie si la liste est vide, si c'est le cas, la fonction affiche un message et retourne NULL.
    if (l == NULL)
    {
        printf("La liste est vide\n");
        return NULL;//NULL car la liste est vide

    }

    //si la liste contient un seul �l�ment, la fonction lib�re cet �l�ment, affiche un message et retourne NULL.
    else if (l->suivant == NULL)
    {
        free(l);
        printf("Votre liste est d�sormais vide \n");
        return NULL;
    }

    //Si la liste contient plus d'un �l�ment
    else
    {
       //On initialise deux pointeurs, p1 et p2, pour parcourir la liste. p1 est initialis� � la t�te de la liste et p2 est initialis� � la deuxi�me cellule de la liste.
       PCelluleDbl p1 = l, p2 = l->suivant;

       //parcourt la liste jusqu'� ce que p2 soit le dernier �l�ment de la liste. � chaque it�ration, p1 et p2 sont avanc�s d'une position dans la liste.
       while(p2->suivant != NULL)
       {
            p1 = p2;
            p2 = p2->suivant;
       }

       //Une fois que p2 est le dernier �l�ment de la liste
       p1->suivant = NULL;//On retire p2 de la liste en mettant � jour le pointeur suivant de p1 pour qu'il pointe vers NULL
       free(p2);//On lib�re la m�moire allou�e � p2.
    }

       return l ;//On retourne la liste

}

PCelluleDbl Presentation(PCelluleDbl maListeDbl)
{
    int donnee=0;
     // Partie faisant r�f�rence aux auteurs du programme
    printf("Bienvenue dans notre programme de gestion de listes doublement chainees.\n");
    printf("Programme realise par : \n");
    printf("1-SONON Charbel  \n");
    printf("2-ADANDEDJAN D�odat \n");
    printf("3-AGBOGBA Silas \n");
    printf("4-ADELABOU Housnath \n");
    printf("5-ADANNOU ZONON Jefferson  \n");
    printf("6-KOUKOUI Uriel \n");
    printf("7-AGONMOUNON Alexa  \n");
    printf("8-BOGNONKPE Prince  \n");
    printf("9-MVOGO Samira  \n\n");

    printf("Dans un premier dans nous allons creer la liste principale.\n");
    // Code pour cr�er une liste chain�e d'entier
    while(donnee<1)
    {
         printf("\nCombien d'elements voulez-vous ajouter a la liste ?Entrez un nombre superieur a 0: ");
         scanf("%d", &donnee);
    }


    // Cr�er la liste en appelant la fonction creerlisteDbl()
       maListeDbl=malloc(sizeof(PCelluleDbl));
       creerListeDbl(maListeDbl,donnee);
       system("clear || cls");
    // Afficher la liste
       afficherListe(maListeDbl);

        system("clear || cls");
        return maListeDbl;
}

PCelluleDbl concatenerCelluleDbl(PCelluleDbl L1, PCelluleDbl L2)
{
   PCelluleDbl p;
    if(L1 == NULL)//Si L1 est vide
    {
        return L2;//La concatenation revient seuleme,nt � L2
    }
    else//Sinon
    {
        p = L1;
        while(p->suivant != NULL)//On parcourt la premiere liste jusqu'� la fin sans ajouter NULL
        {
            p = p->suivant;
        }
        p->suivant = L2;//On ajoute la deuxieme liste � la suite de la premiere
        L2->precedent = p;//La premiere liste devient le precedant de la deuxieme

                triBulle(L1);
                supprimerDoublonsDbl(L1);

        return L1;//On retourne la premiere liste qui est maintenant la concatenation des deux listes
    }



    /*
     PCelluleDbl p1 = l1, p2 = l2, l3=malloc(sizeof(PCelluleDbl)) , last = NULL;
     l3=NULL;

    // initialisation des pointeurs
    // p1 et p2 sont les pointeurs de parcours de l1 et l2
    // l3 est la nouvelle liste concat�n�e
    // last pointe sur le dernier �l�ment ajout� dans l3 (permet de ne pas ajouter de doublons)

    while (p1 != NULL && p2 != NULL)
    {
        // parcours des deux listes tant que p1 et p2 ne sont pas NULL
        if (p1->valeur < p2->valeur)
        {
            // p1->valeur est plus petit, on l'ajoute � l3
            if (last == NULL || p1->valeur != last->valeur)
            {
                ajouterQueue(l3, p1->valeur);
                 if (last != NULL)
                {
                    l3->precedent = last;
                }
                last = l3;
            }
            p1 = p1->suivant;
        }
        else if (p1->valeur > p2->valeur)
        {
            // p2->valeur est plus petit, on l'ajoute � l3
            if (last == NULL || p2->valeur != last->valeur)
            {
                ajouterQueue(l3, p2->valeur);
                 if (last != NULL)
                {
                    l3->precedent = last;
                }
                last = l3;
            }
            p2 = p2->suivant;
        }
        else
        {
            // les deux valeurs sont �gales, on ajoute p1->valeur � l3
            if (last == NULL || p1->valeur != last->valeur)
            {
                 ajouterQueue(l3, p1->valeur);
                 if (last != NULL)
                {
                    l3->precedent = last;
                }
                last = l3;
            }
            p1 = p1->suivant;
            p2 = p2->suivant;
        }
    }

    // ajoute les �l�ments restants de l1 � l3
    while (p1 != NULL)
    {
        if (last == NULL || p1->valeur != last->valeur)
        {
             ajouterQueue(l3, p1->valeur);
             if (last != NULL)
                {
                    l3->precedent = last;
                }
                last = l3;
        }
        p1 = p1->suivant;
    }

    // ajoute les �l�ments restants de l2 � l3
    while (p2 != NULL)
    {
        if (last == NULL || p2->valeur != last->valeur)
        {
            ajouterQueue(l3, p2->valeur);
             if (last != NULL)
                {
                    l3->precedent = last;
                }
                last = l3;
        }
        p2 = p2->suivant;
    }

    // retourne la nouvelle liste concat�n�e
    return l3;
    */

}

void afficherListeDblInverse(PCelluleDbl l)
{
     system("clear || cls");
    printf("Voici votre liste inversee: \n");
    PCelluleDbl p;
    p=l;
    while(p->suivant!=NULL)//On parcourt la liste jusqu'� la fin dans le sens normal en utilisant les pointeurs vers les elements suivant
    {
        p=p->suivant;
    }
    while(p!=NULL)//Puis on la reparcourt dans le sens inverse en utilisant les pointeurs vers les �l�ments pr�c�dants
    {
        printf("%d  ",p->valeur);//On affiche les valeurs de chaque cellule duranr le parcourt en sens inverse
        p=p->precedent;
    }
    printf("\n\n");

}

void listePalindrome(PCelluleDbl l)
{
    system("clear || cls");// Efface l'�cran pour plus de lisibilit�

   //D�claration de deux pointeurs p et q, initialis�s � l, et deux variables i et n=1. n est initialis�e � 1 car la liste a au moins une cellule, celle point�e par l.
    PCelluleDbl p,q;
    int i, n=1;
    p=l;
    q=l;

   // Parcours de la liste jusqu'� la derni�re cellule. � chaque it�ration, q est mis � jour pour pointer sur la cellule suivante et n est incr�ment� de 1.
   //Grace � cela , q pointe vers la derniere cellule et n contient le nombre total d'�l�ment dans la liste
    while(q->suivant!=NULL)
    {
        q=q->suivant;
        n=n+1;
    }


    /*Parcours de la moiti� de la liste (division enti�re de n/2).
      Si la valeur de la cellule point�e par p est diff�rente de celle point�e par q, la fonction affiche "Votre liste n'est pas palindrome." et se termine.
      Sinon, p est mis � jour pour pointer sur la cellule suivante et q sur la pr�c�dente, afin de continuer le parcours de la liste.*/


    for(i=0; i<=n/2; i++)
    {
        if(p->valeur!=q->valeur)
        {
            printf("Votre liste n'est pas palyndrome.\n");
            return;
        }
        else
        {
                 p=p->suivant;
                 q=q->precedent;
        }

    }

        //Si la boucle for se termine sans interruption, c'est que la liste est un palindrome, donc la fonction affiche "Votre liste est palindrome."
        printf("Votre liste est palyndrome.\n");
}


int main() {

    int choixMenu = 0,donnee;
    PCelluleDbl maListeDbl, maListeDbl2; //Initialisation des listes

        system("COLOR 2f");
        maListeDbl=Presentation(maListeDbl);

        system("COLOR 2f");
    // Boucle pour afficher le menu et prendre les choix de l'utilisateur
    do {

        printf("Un Logiciel de QUALITE");
        printf("\t\t\t\t\t\t\t     --GESTION DE  LISTES--\n");
        printf("\t\t\t\t\t\t\t       -----------------------\n");



        printf("\n\t\t\t\t\t\t\t|-------------------------------------|\n");


        printf("\n\t\t\t\t\t\t\t|-------------------------------------|\n");
        printf("\t\t\t\t\t\t\t|\t\tMENU                  |\n");
        printf("\t\t\t\t\t\t\t|\t\t                      |\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t1-- Creer une nouvelle liste chainee d'entier\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t2-- Ajouter un element en t�te de la liste\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t3-- Ajouter un element en queue de la liste\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t4-- Trier la liste\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t5-- Supprimer un element donne de la liste\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t6-- Supprimer les doublons de la liste\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t7-- Supprimer le dernier element de la liste\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t8-- Fusionner la liste avec une deuxieme liste\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t9-- Inverser une liste\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t10-- Verifier si la liste est un palindrome\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t|\t11-- Quitter\n");
        printf("\t\t\t\t|---------------------------------------------------------------------------------------|\n");
        printf("\t\t\t\t\t\t|--Choisissez une option : ");
         while (scanf("%d", &choixMenu) != 1)//permet de s'assurer que l'utilisateur entre un nombre entier
        {
            printf("Erreur: Veuillez entrer un nombre entier : ");
            while (getchar() != '\n'); // Clear the input buffer
        }

        switch (choixMenu) {
            case 1:

                system("clear || cls");
                // Code pour cr�er une liste chain�e d'entier
                printf("Notez que si vous aviez deja cree une liste, cette derniere sera reinitialisee. \nCombien d'elements voulez-vous ajouter a la liste ? ");
                  while (scanf("%d", &donnee) != 1)//permet de s'assurer que l'utilisateur entre un nombre entier
                    {
                        printf("Erreur: Veuillez entrer un nombre entier : ");
                        while (getchar() != '\n'); // Clear the input buffer
                    }

                // Cr�er la liste en appelant la fonction creerlisteDbl()
                maListeDbl=malloc(sizeof(PCelluleDbl));
                creerListeDbl(maListeDbl,donnee);
                 system("clear || cls");
                // Afficher la liste
                afficherListe(maListeDbl);
                break;




            case 2:
                // Code pour ajouter un �l�ment en t�te de liste
                system("clear || cls");
                maListeDbl=ajoutertete(maListeDbl);
                system("clear || cls");
                printf("Apres ajout de l'element en tete,");
                afficherListe(maListeDbl);
                break;


            case 3:
                // Code pour ajouter un �l�ment en queue de liste
                system("clear || cls");
               //Demande � l'utilisateur d'entrer la valeur � ajouter
                printf("Entrez l'element a ajouter : ");
                 while (scanf("%d", &donnee) != 1)//permet de s'assurer que l'utilisateur entre un nombre entier
                    {
                        printf("Erreur: Veuillez entrer un nombre entier : ");
                        while (getchar() != '\n'); // Clear the input buffer
                    }

                ajouterQueue(maListeDbl, donnee);
                system("clear || cls");
                printf("Apres ajout de l'element en queue,\n");
                afficherListe(maListeDbl);
                break;


            case 4:
                // Code pour trier une liste
                system("clear || cls");
                triBulle(maListeDbl);
                system("clear || cls");
                printf("Apres le tri,\n");
                afficherListe(maListeDbl);
                break;


            case 5:
                // Code pour supprimer un �l�ment donn� de la liste
                system("clear || cls");
                printf("Entrez l'element a supprimer:");
                  while (scanf("%d", &donnee) != 1)//permet de s'assurer que l'utilisateur entre un nombre entier
                    {
                        printf("Erreur: Veuillez entrer un nombre entier : ");
                        while (getchar() != '\n'); // Clear the input buffer
                    }
                maListeDbl=supprimerElem(maListeDbl,donnee);
                if(maListeDbl!=NULL)
                {
                    afficherListe(maListeDbl);
                }
                else
                {
                    printf("Votre liste est vide desormais.\n");
                }

                break;


            case 6:
                // Code pour supprimer les doublons de la liste
                system("clear || cls");
                maListeDbl=supprimerDoublonsDbl(maListeDbl);
                system("clear || cls");
                printf("Apres suppression des doublons,\n");
                afficherListe(maListeDbl);
                break;


            case 7:
                // Code pour supprimer le dernier �l�ment de la liste
                system("clear || cls");
                maListeDbl=supprimerDerEle(maListeDbl);
                if (maListeDbl != NULL)
                {
                    system("clear || cls");
                    printf("Apres suppression du dernier element,\n");
                    afficherListe(maListeDbl);
                }
                else
                {
                    system("clear || cls");
                    printf("Apres suppression du dernier element,votre liste est desormais vide.\n");
                }
                break;


            case 8:
                // Code pour fusionner deux listes
                maListeDbl2 = malloc(sizeof(PCelluleDbl));

                system("clear || cls");

                printf("vous devez creer une deuxieme liste\n");
                printf("\nCombien d'elements voulez-vous ajouter a la liste 2? ");
                  while (scanf("%d", &donnee) != 1)//permet de s'assurer que l'utilisateur entre un nombre entier
                    {
                        printf("Erreur: Veuillez entrer un nombre entier : ");
                        while (getchar() != '\n'); // Clear the input buffer
                    }
                creerListeDbl(maListeDbl2,donnee);

                system("clear || cls");

                printf("Votre deuxieme liste est composee de:\n");
                afficherListe(maListeDbl2);
                printf("Pour rappel Votre premi�re liste est composee de:\n");
                afficherListe(maListeDbl);

                printf("Apres la fusion des deux listes,tri et suppression des doublons,\n");
                maListeDbl = concatenerCelluleDbl(maListeDbl, maListeDbl2);
                afficherListe(maListeDbl);
                break;


            case 9:
                // Code pour inverser une liste
                system("clear || cls");
                afficherListeDblInverse(maListeDbl);
                break;


            case 10:
                // Code pour v�rifier si une liste est un palindrome
                system("clear || cls");
                listePalindrome(maListeDbl);
                afficherListe(maListeDbl);
                break;


            case 11:
                 system("clear || cls");
                printf("Au revoir !");
                break;

            default:
                system("clear || cls");
                printf("Choix invalide. Veuillez r�essayer.\n");
        }
    } while (choixMenu != 11);

    return 0;
}
